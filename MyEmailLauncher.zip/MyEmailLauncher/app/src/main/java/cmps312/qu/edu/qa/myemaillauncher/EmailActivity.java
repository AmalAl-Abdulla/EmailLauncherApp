package cmps312.qu.edu.qa.myemaillauncher;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class EmailActivity extends AppCompatActivity {
    ImageView imageView;
    TextView subjectTextView, bodyTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);

        imageView = (ImageView) findViewById(R.id.imageView);
        subjectTextView = (TextView) findViewById(R.id.subject_content_text_view);
        bodyTextView = (TextView) findViewById(R.id.body_content_text_view);

        String text = getIntent().getStringExtra(Intent.EXTRA_SUBJECT);
        subjectTextView.setText(text);

        String text2 = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        bodyTextView.setText(text2);

        Uri receivedUri = (Uri) getIntent().getParcelableExtra(Intent.EXTRA_STREAM);
        if(receivedUri!=null)
            imageView.setImageURI(receivedUri);
        else
            Toast.makeText(EmailActivity.this,"ERROR OCCURED",Toast.LENGTH_SHORT).show();
    }

}
